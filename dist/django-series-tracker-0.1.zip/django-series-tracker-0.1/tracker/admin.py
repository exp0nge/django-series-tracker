from django.contrib import admin

from tracker.models import Series
# Register your models here.
admin.site.register(Series)